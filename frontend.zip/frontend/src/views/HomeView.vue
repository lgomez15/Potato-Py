<script setup>
    import { ref } from 'vue';
    import { RouterLink } from 'vue-router';
</script>


<template>
    <div>
        <h1>Home</h1>
        <p>Welcome to your home page with Vue.js app!</p>
    </div>
</template>

<style scoped>

</style>