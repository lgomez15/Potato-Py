<template>
    <div>
        <h1>404</h1>
        <p>Page not found</p>
    </div>
</template>

<style scoped>
    h1 {
        color: #35495e;
    }
    p {
        color: #41b883;
    }
</style>

